﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace game.BL
{
    class Player
    {
        public int PX;
        public int PY;
    } 
    class Enemy
    {
        public int E1X;
        public int E1Y;
        public string direction;
    }
    class Bullet
    {
        public int bulletx;
        public int bullety;
        public bool isbulletactive;
    }
}
