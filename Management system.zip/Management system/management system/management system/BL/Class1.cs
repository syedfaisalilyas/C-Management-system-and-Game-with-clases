﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace management_system.BL
{
    class SignUp
    {
        public string username;
        public string password;
        public string contactNumber;
        public string Email;
        public string Role;

    }
  

    class society
    {
        public string society_member_username;
        public string society_member_email;
        public string society_member_contact;

    }
}
